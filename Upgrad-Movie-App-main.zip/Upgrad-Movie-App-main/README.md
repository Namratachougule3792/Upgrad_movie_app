# Upgrad-Movie-App

This project is made for the "UPGRAD".
